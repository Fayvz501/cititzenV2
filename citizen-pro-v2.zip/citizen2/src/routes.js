const express = require('express');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('./database');
const { generateToken, authMiddleware, optionalAuth, modOnly, getVoteWeight } = require('./auth');
const { checkAndAward, getUserAchievements } = require('./achievements');
const { fullModeration } = require('./moderation');
const { notifyChannel, notifySOS } = require('./telegram');
const { subscribe, unsubscribe, sendToUser, sendToNearby, getVapidPublicKey, haversine } = require('./push');

const router = express.Router();

// ── File upload config ──
const storage = multer.diskStorage({
  destination: path.join(__dirname, '..', 'public', 'uploads'),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, uuidv4() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|mp4|webm/;
    cb(null, allowed.test(path.extname(file.originalname).toLowerCase()) && allowed.test(file.mimetype.split('/')[1]));
  }
});

// ════════════════════════════════════════
//  AUTH
// ════════════════════════════════════════
router.post('/auth/register', async (req, res) => {
  try {
    const { username, email, password, lang } = req.body;
    if (!username || !email || !password) return res.status(400).json({ error: 'Все поля обязательны' });
    if (username.length < 3 || username.length > 20) return res.status(400).json({ error: 'Имя: 3-20 символов' });
    if (password.length < 6) return res.status(400).json({ error: 'Пароль: минимум 6 символов' });

    const db = getDb();
    if (db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email))
      return res.status(409).json({ error: 'Пользователь уже существует' });

    const hash = await bcrypt.hash(password, 10);
    const colors = ['#ff3b3b','#ff8c00','#ffd000','#3b8bff','#00d97e','#a855f7','#f472b6','#06b6d4'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    const r = db.prepare('INSERT INTO users (username, email, password_hash, avatar_color, lang) VALUES (?,?,?,?,?)')
      .run(username, email, hash, color, lang || 'ru');
    const user = db.prepare('SELECT id,username,email,avatar_color,reputation,is_streamer,trust_level,lang FROM users WHERE id=?').get(r.lastInsertRowid);
    res.json({ token: generateToken(user), user });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

router.post('/auth/login', async (req, res) => {
  try {
    const { login, password } = req.body;
    if (!login || !password) return res.status(400).json({ error: 'Введите логин и пароль' });
    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE username=? OR email=?').get(login, login);
    if (!user || !(await bcrypt.compare(password, user.password_hash)))
      return res.status(401).json({ error: 'Неверный логин или пароль' });

    db.prepare('UPDATE users SET last_active=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
    res.json({
      token: generateToken(user),
      user: { id: user.id, username: user.username, email: user.email, avatar_color: user.avatar_color, reputation: user.reputation, is_streamer: user.is_streamer, trust_level: user.trust_level, lang: user.lang }
    });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

router.get('/auth/me', authMiddleware, (req, res) => {
  const db = getDb();
  const u = db.prepare('SELECT id,username,email,avatar_color,reputation,is_streamer,trust_level,is_patrolling,lang,created_at FROM users WHERE id=?').get(req.user.id);
  if (!u) return res.status(404).json({ error: 'Не найден' });
  const achievements = getUserAchievements(req.user.id);
  res.json({ user: u, achievements });
});

router.patch('/auth/streamer', authMiddleware, (req, res) => {
  const db = getDb();
  const u = db.prepare('SELECT is_streamer FROM users WHERE id=?').get(req.user.id);
  const v = u.is_streamer ? 0 : 1;
  db.prepare('UPDATE users SET is_streamer=? WHERE id=?').run(v, req.user.id);
  res.json({ is_streamer: v });
});

router.patch('/auth/lang', authMiddleware, (req, res) => {
  const { lang } = req.body;
  if (!['ru','en'].includes(lang)) return res.status(400).json({ error: 'ru or en' });
  getDb().prepare('UPDATE users SET lang=? WHERE id=?').run(lang, req.user.id);
  res.json({ lang });
});

router.patch('/auth/trust', authMiddleware, modOnly, (req, res) => {
  const { user_id, trust_level } = req.body;
  if (!['newcomer','verified','moderator'].includes(trust_level)) return res.status(400).json({ error: 'Invalid level' });
  getDb().prepare('UPDATE users SET trust_level=? WHERE id=?').run(trust_level, user_id);
  res.json({ success: true });
});

// ════════════════════════════════════════
//  INCIDENTS
// ════════════════════════════════════════
router.get('/incidents', optionalAuth, (req, res) => {
  const db = getDb();
  const hours = parseInt(req.query.hours) || 24;
  const type = req.query.type;
  let sql = `SELECT i.*, u.username, u.avatar_color, u.reputation, u.trust_level,
    (SELECT COUNT(*) FROM votes WHERE incident_id=i.id AND vote_type='confirm') as confirms,
    (SELECT COUNT(*) FROM votes WHERE incident_id=i.id AND vote_type='fake') as fakes,
    (SELECT COUNT(*) FROM comments WHERE incident_id=i.id) as comment_count,
    (SELECT COUNT(*) FROM chat_messages WHERE incident_id=i.id) as chat_count,
    (SELECT COUNT(*) FROM streamer_claims WHERE incident_id=i.id AND status!='finished') as active_streamers,
    (SELECT GROUP_CONCAT(filename) FROM incident_media WHERE incident_id=i.id) as media_files
    FROM incidents i JOIN users u ON i.user_id=u.id
    WHERE i.created_at > datetime('now', '-${hours} hours') AND i.status != 'fake'`;
  if (type && type !== 'all') sql += ` AND i.type='${type}'`;
  sql += ' ORDER BY i.is_emergency DESC, i.created_at DESC';
  res.json({ incidents: db.prepare(sql).all() });
});

router.post('/incidents', authMiddleware, upload.array('media', 5), async (req, res) => {
  try {
    const { type, description, address, lat, lng, severity } = req.body;
    if (!type || !description || lat == null || lng == null)
      return res.status(400).json({ error: 'Заполните обязательные поля' });

    // Moderation
    const mod = await fullModeration(description);
    if (!mod.passed) return res.status(400).json({ error: 'Сообщение не прошло модерацию', flags: mod.flags });

    const db = getDb();
    const uid = 'inc_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    const isSos = type === 'sos' ? 1 : 0;

    db.prepare(`INSERT INTO incidents (uid,user_id,type,description,address,lat,lng,severity,is_emergency,moderation_score)
      VALUES (?,?,?,?,?,?,?,?,?,?)`).run(uid, req.user.id, type, description, address||null, parseFloat(lat), parseFloat(lng), parseInt(severity)||1, isSos, mod.score);

    const incident = db.prepare(`SELECT i.*, u.username, u.avatar_color, u.reputation, u.trust_level,
      0 as confirms, 0 as fakes, 0 as comment_count, 0 as chat_count, 0 as active_streamers, NULL as media_files
      FROM incidents i JOIN users u ON i.user_id=u.id WHERE i.uid=?`).get(uid);

    // Save media
    if (req.files && req.files.length) {
      for (const f of req.files) {
        db.prepare('INSERT INTO incident_media (incident_id,user_id,filename,original_name,mime_type) VALUES (?,?,?,?,?)')
          .run(incident.id, req.user.id, f.filename, f.originalname, f.mimetype);
      }
      incident.media_files = req.files.map(f => f.filename).join(',');
    }

    // Timeline entry
    db.prepare('INSERT INTO incident_timeline (incident_id,user_id,event_type,description) VALUES (?,?,?,?)')
      .run(incident.id, req.user.id, 'created', 'Событие создано');

    // Reputation
    db.prepare('UPDATE users SET reputation=reputation+1 WHERE id=?').run(req.user.id);

    // Achievements
    const newAch = checkAndAward(req.user.id);

    // Notify nearby users
    notifyNearbyDb(db, incident);
    sendToNearby(incident.lat, incident.lng, 5, {
      title: `⚡ ${description.substring(0, 50)}`,
      body: address || 'Новое событие рядом',
      data: { uid }
    }, req.user.id);

    // Telegram
    notifyChannel({ ...incident, username: req.user.username });
    if (isSos) notifySOS({ ...incident, username: req.user.username });

    res.json({ incident, new_achievements: newAch });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

router.patch('/incidents/:uid/resolve', authMiddleware, (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT * FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  if (inc.user_id !== req.user.id && !['moderator','admin'].includes(req.user.trust || ''))
    return res.status(403).json({ error: 'Нет прав' });
  db.prepare("UPDATE incidents SET status='resolved', resolved_at=CURRENT_TIMESTAMP WHERE uid=?").run(req.params.uid);
  db.prepare('INSERT INTO incident_timeline (incident_id,user_id,event_type,description) VALUES (?,?,?,?)')
    .run(inc.id, req.user.id, 'resolved', 'Событие закрыто');
  res.json({ success: true });
});

router.delete('/incidents/:uid', authMiddleware, modOnly, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM incidents WHERE uid=?').run(req.params.uid);
  res.json({ success: true });
});

// ── Upload media to existing incident ──
router.post('/incidents/:uid/media', authMiddleware, upload.array('media', 5), (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  const files = [];
  for (const f of (req.files || [])) {
    db.prepare('INSERT INTO incident_media (incident_id,user_id,filename,original_name,mime_type) VALUES (?,?,?,?,?)')
      .run(inc.id, req.user.id, f.filename, f.originalname, f.mimetype);
    files.push(f.filename);
  }
  res.json({ files });
});

// ════════════════════════════════════════
//  TIMELINE
// ════════════════════════════════════════
router.get('/incidents/:uid/timeline', (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  const timeline = db.prepare(`SELECT t.*, u.username, u.avatar_color FROM incident_timeline t
    LEFT JOIN users u ON t.user_id=u.id WHERE t.incident_id=? ORDER BY t.created_at ASC`).all(inc.id);
  res.json({ timeline });
});

// ════════════════════════════════════════
//  VOTES (with trust weight)
// ════════════════════════════════════════
router.post('/incidents/:uid/vote', authMiddleware, (req, res) => {
  try {
    const { vote_type } = req.body;
    if (!['confirm','fake'].includes(vote_type)) return res.status(400).json({ error: 'confirm or fake' });
    const db = getDb();
    const inc = db.prepare('SELECT id,user_id,uid FROM incidents WHERE uid=?').get(req.params.uid);
    if (!inc) return res.status(404).json({ error: 'Не найдено' });
    if (inc.user_id === req.user.id) return res.status(400).json({ error: 'Нельзя голосовать за своё' });

    const user = db.prepare('SELECT trust_level FROM users WHERE id=?').get(req.user.id);
    const weight = getVoteWeight(user.trust_level);
    const existing = db.prepare('SELECT id,vote_type FROM votes WHERE incident_id=? AND user_id=?').get(inc.id, req.user.id);

    if (existing) {
      if (existing.vote_type === vote_type) db.prepare('DELETE FROM votes WHERE id=?').run(existing.id);
      else db.prepare('UPDATE votes SET vote_type=?,weight=? WHERE id=?').run(vote_type, weight, existing.id);
    } else {
      db.prepare('INSERT INTO votes (incident_id,user_id,vote_type,weight) VALUES (?,?,?,?)').run(inc.id, req.user.id, vote_type, weight);
    }

    const confirms = db.prepare("SELECT COALESCE(SUM(weight),0) as w FROM votes WHERE incident_id=? AND vote_type='confirm'").get(inc.id).w;
    const fakes = db.prepare("SELECT COALESCE(SUM(weight),0) as w FROM votes WHERE incident_id=? AND vote_type='fake'").get(inc.id).w;

    if (fakes >= 8 && fakes > confirms * 2) {
      db.prepare("UPDATE incidents SET status='fake' WHERE id=?").run(inc.id);
      db.prepare('INSERT INTO incident_timeline (incident_id,event_type,description) VALUES (?,?,?)').run(inc.id, 'marked_fake', 'Помечено как фейк сообществом');
    } else if (confirms >= 5) {
      db.prepare("UPDATE incidents SET status='confirmed' WHERE id=?").run(inc.id);
      db.prepare('UPDATE users SET reputation=reputation+2 WHERE id=?').run(inc.user_id);
      db.prepare('INSERT INTO incident_timeline (incident_id,event_type,description) VALUES (?,?,?)').run(inc.id, 'confirmed', 'Подтверждено сообществом');
    }

    checkAndAward(req.user.id);
    res.json({ confirms: Math.round(confirms), fakes: Math.round(fakes) });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка' }); }
});

// ════════════════════════════════════════
//  COMMENTS
// ════════════════════════════════════════
router.get('/incidents/:uid/comments', (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  res.json({ comments: db.prepare(`SELECT c.*, u.username, u.avatar_color, u.reputation, u.trust_level
    FROM comments c JOIN users u ON c.user_id=u.id WHERE c.incident_id=? ORDER BY c.created_at ASC`).all(inc.id) });
});

router.post('/incidents/:uid/comments', authMiddleware, async (req, res) => {
  try {
    const { text } = req.body;
    if (!text?.trim()) return res.status(400).json({ error: 'Пустой комментарий' });
    const mod = await fullModeration(text);
    if (!mod.passed) return res.status(400).json({ error: 'Не прошло модерацию' });

    const db = getDb();
    const inc = db.prepare('SELECT id,user_id FROM incidents WHERE uid=?').get(req.params.uid);
    if (!inc) return res.status(404).json({ error: 'Не найдено' });

    const r = db.prepare('INSERT INTO comments (incident_id,user_id,text) VALUES (?,?,?)').run(inc.id, req.user.id, text.trim());
    const comment = db.prepare('SELECT c.*,u.username,u.avatar_color,u.reputation,u.trust_level FROM comments c JOIN users u ON c.user_id=u.id WHERE c.id=?').get(r.lastInsertRowid);

    if (inc.user_id !== req.user.id) {
      db.prepare("INSERT INTO notifications (user_id,incident_id,type,message,message_en) VALUES (?,?,?,?,?)")
        .run(inc.user_id, inc.id, 'comment', `${req.user.username} прокомментировал`, `${req.user.username} commented`);
      sendToUser(inc.user_id, { title: '💬 Новый комментарий', body: text.substring(0, 80) });
    }

    checkAndAward(req.user.id);
    res.json({ comment });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка' }); }
});

// ════════════════════════════════════════
//  REALTIME CHAT
// ════════════════════════════════════════
router.get('/incidents/:uid/chat', (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  const limit = parseInt(req.query.limit) || 50;
  res.json({ messages: db.prepare(`SELECT m.*,u.username,u.avatar_color FROM chat_messages m
    JOIN users u ON m.user_id=u.id WHERE m.incident_id=? ORDER BY m.created_at DESC LIMIT ?`).all(inc.id, limit).reverse() });
});

router.post('/incidents/:uid/chat', authMiddleware, async (req, res) => {
  const { text } = req.body;
  if (!text?.trim()) return res.status(400).json({ error: 'Пустое сообщение' });
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  const r = db.prepare('INSERT INTO chat_messages (incident_id,user_id,text) VALUES (?,?,?)').run(inc.id, req.user.id, text.trim());
  const msg = db.prepare('SELECT m.*,u.username,u.avatar_color FROM chat_messages m JOIN users u ON m.user_id=u.id WHERE m.id=?').get(r.lastInsertRowid);
  res.json({ message: msg });
});

// ════════════════════════════════════════
//  STREAMERS
// ════════════════════════════════════════
router.post('/incidents/:uid/claim', authMiddleware, (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id,uid FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  try {
    db.prepare('INSERT INTO streamer_claims (incident_id,user_id) VALUES (?,?)').run(inc.id, req.user.id);
    db.prepare("UPDATE incidents SET status='responding' WHERE id=? AND status='active'").run(inc.id);
    db.prepare('INSERT INTO incident_timeline (incident_id,user_id,event_type,description) VALUES (?,?,?,?)')
      .run(inc.id, req.user.id, 'streamer_claimed', `Стример ${req.user.username} выезжает`);
    checkAndAward(req.user.id);
    res.json({ success: true });
  } catch (e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ error: 'Уже заявлено' });
    throw e;
  }
});

router.patch('/incidents/:uid/arrive', authMiddleware, (req, res) => {
  const db = getDb();
  const inc = db.prepare('SELECT id FROM incidents WHERE uid=?').get(req.params.uid);
  if (!inc) return res.status(404).json({ error: 'Не найдено' });
  db.prepare("UPDATE streamer_claims SET status='on_scene', arrived_at=CURRENT_TIMESTAMP WHERE incident_id=? AND user_id=?").run(inc.id, req.user.id);
  db.prepare('INSERT INTO incident_timeline (incident_id,user_id,event_type,description) VALUES (?,?,?,?)')
    .run(inc.id, req.user.id, 'streamer_arrived', `Стример ${req.user.username} на месте`);
  res.json({ success: true });
});

// ════════════════════════════════════════
//  SOS
// ════════════════════════════════════════
router.post('/sos', authMiddleware, (req, res) => {
  const { lat, lng, description } = req.body;
  if (lat == null || lng == null) return res.status(400).json({ error: 'Нужны координаты' });
  const db = getDb();
  const uid = 'sos_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');

  db.prepare(`INSERT INTO incidents (uid,user_id,type,description,lat,lng,severity,is_emergency,status)
    VALUES (?,?,'sos',?,?,?,5,1,'active')`)
    .run(uid, req.user.id, description || 'SOS! Нужна помощь!', parseFloat(lat), parseFloat(lng));

  const inc = db.prepare('SELECT * FROM incidents WHERE uid=?').get(uid);
  db.prepare('INSERT INTO incident_timeline (incident_id,user_id,event_type,description) VALUES (?,?,?,?)')
    .run(inc.id, req.user.id, 'sos', 'Тревожная кнопка активирована');

  // Notify EVERYONE nearby
  sendToNearby(lat, lng, 10, { title: '🆘 SOS ТРЕВОГА', body: 'Пользователь рядом просит помощь!', data: { uid } }, req.user.id);
  notifySOS({ ...inc, username: req.user.username });

  res.json({ incident: inc });
});

// ════════════════════════════════════════
//  PATROL
// ════════════════════════════════════════
router.patch('/patrol/toggle', authMiddleware, (req, res) => {
  const db = getDb();
  const u = db.prepare('SELECT is_patrolling FROM users WHERE id=?').get(req.user.id);
  const v = u.is_patrolling ? 0 : 1;
  db.prepare('UPDATE users SET is_patrolling=? WHERE id=?').run(v, req.user.id);
  res.json({ is_patrolling: v });
});

router.post('/patrol/location', authMiddleware, (req, res) => {
  const { lat, lng } = req.body;
  getDb().prepare('UPDATE users SET patrol_lat=?, patrol_lng=?, last_active=CURRENT_TIMESTAMP WHERE id=?')
    .run(parseFloat(lat), parseFloat(lng), req.user.id);
  res.json({ success: true });
});

router.get('/patrol/active', (req, res) => {
  const patrols = getDb().prepare(`SELECT id,username,avatar_color,patrol_lat,patrol_lng
    FROM users WHERE is_patrolling=1 AND patrol_lat IS NOT NULL
    AND last_active > datetime('now','-10 minutes')`).all();
  res.json({ patrols });
});

// ════════════════════════════════════════
//  EMERGENCY ALERTS (admin/mod)
// ════════════════════════════════════════
router.post('/emergency', authMiddleware, modOnly, (req, res) => {
  const { title, message, lat, lng, radius_km, expires_hours } = req.body;
  if (!title || !message || lat == null || lng == null)
    return res.status(400).json({ error: 'Заполните все поля' });
  const db = getDb();
  const exp = expires_hours ? `datetime('now', '+${parseInt(expires_hours)} hours')` : null;
  db.prepare(`INSERT INTO emergency_alerts (user_id,title,message,lat,lng,radius_km,expires_at)
    VALUES (?,?,?,?,?,?,${exp ? exp : 'NULL'})`).run(req.user.id, title, message, lat, lng, radius_km || 5);

  sendToNearby(lat, lng, radius_km || 5, { title: `🚨 ${title}`, body: message }, null);
  res.json({ success: true });
});

router.get('/emergency/active', (req, res) => {
  const alerts = getDb().prepare(`SELECT * FROM emergency_alerts
    WHERE active=1 AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)
    ORDER BY created_at DESC`).all();
  res.json({ alerts });
});

// ════════════════════════════════════════
//  NOTIFICATIONS
// ════════════════════════════════════════
router.get('/notifications', authMiddleware, (req, res) => {
  const db = getDb();
  const notifs = db.prepare(`SELECT n.*, i.uid as incident_uid, i.type as incident_type
    FROM notifications n LEFT JOIN incidents i ON n.incident_id=i.id
    WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 50`).all(req.user.id);
  const unread = db.prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id=? AND is_read=0').get(req.user.id).c;
  res.json({ notifications: notifs, unread });
});

router.patch('/notifications/read', authMiddleware, (req, res) => {
  getDb().prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id);
  res.json({ success: true });
});

// ════════════════════════════════════════
//  PUSH SUBSCRIPTIONS
// ════════════════════════════════════════
router.get('/push/vapid', (req, res) => { res.json({ key: getVapidPublicKey() }); });
router.post('/push/subscribe', authMiddleware, (req, res) => {
  const ok = subscribe(req.user.id, req.body);
  res.json({ success: ok });
});
router.post('/push/unsubscribe', authMiddleware, (req, res) => {
  unsubscribe(req.user.id, req.body.endpoint);
  res.json({ success: true });
});

// ════════════════════════════════════════
//  ZONES
// ════════════════════════════════════════
router.get('/zones', authMiddleware, (req, res) => {
  res.json({ zones: getDb().prepare('SELECT * FROM user_zones WHERE user_id=?').all(req.user.id) });
});
router.post('/zones', authMiddleware, (req, res) => {
  const { label, lat, lng, radius_km } = req.body;
  if (lat == null || lng == null) return res.status(400).json({ error: 'Координаты обязательны' });
  const db = getDb();
  try {
    db.prepare('INSERT INTO user_zones (user_id,label,lat,lng,radius_km) VALUES (?,?,?,?,?)').run(req.user.id, label||'Мой район', lat, lng, radius_km||2);
    res.json({ success: true });
  } catch (e) {
    db.prepare('UPDATE user_zones SET lat=?,lng=?,radius_km=? WHERE user_id=? AND label=?').run(lat, lng, radius_km||2, req.user.id, label||'Мой район');
    res.json({ success: true });
  }
});
router.delete('/zones/:id', authMiddleware, (req, res) => {
  getDb().prepare('DELETE FROM user_zones WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  res.json({ success: true });
});

// ════════════════════════════════════════
//  ANALYTICS
// ════════════════════════════════════════
router.get('/analytics/overview', (req, res) => {
  const db = getDb();
  const byType = db.prepare("SELECT type, COUNT(*) as count FROM incidents WHERE created_at>datetime('now','-7 days') AND status!='fake' GROUP BY type ORDER BY count DESC").all();
  const byHour = db.prepare("SELECT strftime('%H',created_at) as hour, COUNT(*) as count FROM incidents WHERE created_at>datetime('now','-24 hours') AND status!='fake' GROUP BY hour ORDER BY hour").all();
  const byDay = db.prepare("SELECT date(created_at) as day, COUNT(*) as count FROM incidents WHERE created_at>datetime('now','-30 days') AND status!='fake' GROUP BY day ORDER BY day").all();
  const byDayOfWeek = db.prepare("SELECT CAST(strftime('%w',created_at) AS INTEGER) as dow, COUNT(*) as count FROM incidents WHERE created_at>datetime('now','-30 days') AND status!='fake' GROUP BY dow ORDER BY dow").all();
  const heatmap = db.prepare("SELECT lat,lng,type,(SELECT COUNT(*) FROM votes WHERE incident_id=incidents.id AND vote_type='confirm') as weight FROM incidents WHERE created_at>datetime('now','-7 days') AND status!='fake'").all();
  const hotspots = db.prepare("SELECT ROUND(lat,2) as area_lat, ROUND(lng,2) as area_lng, COUNT(*) as count FROM incidents WHERE created_at>datetime('now','-7 days') AND status!='fake' GROUP BY area_lat,area_lng ORDER BY count DESC LIMIT 10").all();
  const totals = db.prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status='confirmed' THEN 1 ELSE 0 END) as confirmed, SUM(CASE WHEN status='resolved' THEN 1 ELSE 0 END) as resolved, SUM(CASE WHEN type='sos' THEN 1 ELSE 0 END) as sos FROM incidents WHERE created_at>datetime('now','-7 days')").get();
  const streamers = db.prepare("SELECT COUNT(DISTINCT user_id) as count FROM streamer_claims WHERE status!='finished' AND claimed_at>datetime('now','-24 hours')").get();
  const avgResponse = db.prepare("SELECT AVG((julianday(arrived_at)-julianday(claimed_at))*24*60) as avg_min FROM streamer_claims WHERE arrived_at IS NOT NULL AND claimed_at>datetime('now','-7 days')").get();
  res.json({ byType, byHour, byDay, byDayOfWeek, heatmap, hotspots, totals: { ...totals, active_streamers: streamers.count, avg_response_min: avgResponse?.avg_min ? Math.round(avgResponse.avg_min) : null } });
});

router.get('/analytics/leaderboard', (req, res) => {
  const users = getDb().prepare(`SELECT u.id,u.username,u.avatar_color,u.reputation,u.is_streamer,u.trust_level,
    (SELECT COUNT(*) FROM incidents WHERE user_id=u.id AND status!='fake') as reports,
    (SELECT COUNT(*) FROM votes WHERE user_id=u.id) as votes_cast,
    (SELECT COUNT(*) FROM comments WHERE user_id=u.id) as comments_made,
    (SELECT COUNT(*) FROM achievements WHERE user_id=u.id) as achievement_count
    FROM users u ORDER BY u.reputation DESC LIMIT 20`).all();
  res.json({ leaderboard: users });
});

router.get('/analytics/safety', (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'lat & lng required' });
  const db = getDb();
  const radius = 0.02; // ~2km
  const incidents = db.prepare(`SELECT type, COUNT(*) as count FROM incidents
    WHERE lat BETWEEN ?-? AND ?+? AND lng BETWEEN ?-? AND ?+?
    AND created_at>datetime('now','-30 days') AND status!='fake'
    GROUP BY type`).all(parseFloat(lat), radius, parseFloat(lat), radius, parseFloat(lng), radius, parseFloat(lng), radius);

  const total = incidents.reduce((s, i) => s + i.count, 0);
  const score = Math.max(0, Math.round(100 - total * 3));
  const level = score >= 80 ? 'safe' : score >= 50 ? 'moderate' : 'dangerous';
  res.json({ score, level, total_incidents: total, breakdown: incidents });
});

// ════════════════════════════════════════
//  USER PROFILE / DASHBOARD
// ════════════════════════════════════════
router.get('/users/:id/profile', (req, res) => {
  const db = getDb();
  const u = db.prepare('SELECT id,username,avatar_color,reputation,is_streamer,trust_level,created_at FROM users WHERE id=?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'Не найден' });

  const stats = {
    reports: db.prepare("SELECT COUNT(*) as c FROM incidents WHERE user_id=? AND status!='fake'").get(u.id).c,
    confirmed: db.prepare("SELECT COUNT(*) as c FROM incidents WHERE user_id=? AND status='confirmed'").get(u.id).c,
    votes: db.prepare('SELECT COUNT(*) as c FROM votes WHERE user_id=?').get(u.id).c,
    comments: db.prepare('SELECT COUNT(*) as c FROM comments WHERE user_id=?').get(u.id).c,
    streams: db.prepare('SELECT COUNT(*) as c FROM streamer_claims WHERE user_id=?').get(u.id).c,
  };

  const recentActivity = db.prepare(`SELECT type, lat, lng, created_at FROM incidents
    WHERE user_id=? AND status!='fake' ORDER BY created_at DESC LIMIT 20`).all(u.id);

  const byType = db.prepare("SELECT type, COUNT(*) as count FROM incidents WHERE user_id=? AND status!='fake' GROUP BY type").all(u.id);
  const achievements = getUserAchievements(u.id);

  res.json({ user: u, stats, recentActivity, byType, achievements });
});

// ── ACHIEVEMENTS ──
router.get('/achievements', authMiddleware, (req, res) => {
  res.json({ achievements: getUserAchievements(req.user.id) });
});

// ── HELPER ──
function notifyNearbyDb(db, incident) {
  const zones = db.prepare('SELECT * FROM user_zones').all();
  for (const z of zones) {
    if (z.user_id === incident.user_id) continue;
    if (haversine(z.lat, z.lng, incident.lat, incident.lng) <= z.radius_km) {
      db.prepare("INSERT INTO notifications (user_id,incident_id,type,message,message_en) VALUES (?,?,?,?,?)")
        .run(z.user_id, incident.id, 'zone_alert',
          `Новое событие в зоне "${z.label}"`,
          `New incident in zone "${z.label}"`);
    }
  }
}

module.exports = router;

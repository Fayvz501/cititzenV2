const { getDb } = require('./database');

const ACHIEVEMENTS = {
  first_report:    { icon: '🏅', name: 'Первый репорт',      name_en: 'First Report',      desc: 'Создайте первое происшествие',        check: u => u.reports >= 1 },
  reporter_10:     { icon: '📰', name: 'Репортёр',           name_en: 'Reporter',           desc: '10 происшествий',                     check: u => u.reports >= 10 },
  reporter_50:     { icon: '🗞️', name: 'Журналист',          name_en: 'Journalist',         desc: '50 происшествий',                     check: u => u.reports >= 50 },
  night_watch:     { icon: '🌙', name: 'Ночной дозор',       name_en: 'Night Watch',        desc: 'Репорт после полуночи',                check: u => u.night_reports >= 1 },
  detective:       { icon: '🔍', name: 'Детектив',           name_en: 'Detective',          desc: '10 подтверждённых событий',            check: u => u.confirmed >= 10 },
  guardian:        { icon: '🛡️', name: 'Страж',              name_en: 'Guardian',           desc: '5 обнаруженных фейков',                check: u => u.fakes_found >= 5 },
  commentator:     { icon: '💬', name: 'Комментатор',        name_en: 'Commentator',        desc: '20 комментариев',                     check: u => u.comments >= 20 },
  streamer_first:  { icon: '🎥', name: 'На месте!',          name_en: 'On Scene!',          desc: 'Первый выезд как стример',             check: u => u.streams >= 1 },
  streamer_pro:    { icon: '📡', name: 'Стример-про',        name_en: 'Pro Streamer',       desc: '10 выездов',                           check: u => u.streams >= 10 },
  voter:           { icon: '✅', name: 'Активист',           name_en: 'Activist',           desc: '50 голосов',                           check: u => u.votes >= 50 },
  helper:          { icon: '🆘', name: 'Спасатель',          name_en: 'Rescuer',            desc: 'Откликнуться на SOS',                  check: u => u.sos_responses >= 1 },
  patrol_night:    { icon: '🔦', name: 'Патрульный',         name_en: 'Patrol Officer',     desc: 'Первый ночной патруль',                check: u => u.patrols >= 1 },
  reputation_100:  { icon: '⭐', name: 'Авторитет',          name_en: 'Authority',          desc: 'Репутация 100+',                       check: u => u.reputation >= 100 },
  early_bird:      { icon: '🐦', name: 'Ранняя пташка',     name_en: 'Early Bird',         desc: 'Репорт до 6 утра',                     check: u => u.early_reports >= 1 },
  week_streak:     { icon: '🔥', name: 'Недельный страйк',  name_en: 'Week Streak',        desc: 'Активность 7 дней подряд',             check: u => u.streak >= 7 },
};

function checkAndAward(userId) {
  const db = getDb();
  const existing = new Set(db.prepare('SELECT achievement_key FROM achievements WHERE user_id = ?').all(userId).map(a => a.achievement_key));

  const stats = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM incidents WHERE user_id = ? AND status != 'fake') as reports,
      (SELECT COUNT(*) FROM incidents WHERE user_id = ? AND status = 'confirmed') as confirmed,
      (SELECT COUNT(*) FROM incidents WHERE user_id = ? AND status != 'fake' AND CAST(strftime('%H', created_at) AS INTEGER) >= 0 AND CAST(strftime('%H', created_at) AS INTEGER) < 5) as night_reports,
      (SELECT COUNT(*) FROM incidents WHERE user_id = ? AND status != 'fake' AND CAST(strftime('%H', created_at) AS INTEGER) >= 4 AND CAST(strftime('%H', created_at) AS INTEGER) < 6) as early_reports,
      (SELECT COUNT(*) FROM votes WHERE user_id = ?) as votes,
      (SELECT COUNT(*) FROM votes v JOIN incidents i ON v.incident_id = i.id WHERE v.user_id = ? AND v.vote_type = 'fake' AND i.status = 'fake') as fakes_found,
      (SELECT COUNT(*) FROM comments WHERE user_id = ?) as comments,
      (SELECT COUNT(*) FROM streamer_claims WHERE user_id = ?) as streams,
      (SELECT reputation FROM users WHERE id = ?) as reputation,
      0 as sos_responses,
      0 as patrols,
      0 as streak
  `).get(userId, userId, userId, userId, userId, userId, userId, userId, userId);

  const newAchievements = [];
  for (const [key, ach] of Object.entries(ACHIEVEMENTS)) {
    if (existing.has(key)) continue;
    if (ach.check(stats)) {
      try {
        db.prepare('INSERT INTO achievements (user_id, achievement_key) VALUES (?, ?)').run(userId, key);
        newAchievements.push({ key, ...ach });
      } catch {}
    }
  }
  return newAchievements;
}

function getUserAchievements(userId) {
  const db = getDb();
  const unlocked = db.prepare('SELECT achievement_key, unlocked_at FROM achievements WHERE user_id = ?').all(userId);
  return Object.entries(ACHIEVEMENTS).map(([key, ach]) => {
    const u = unlocked.find(a => a.achievement_key === key);
    return { key, ...ach, unlocked: !!u, unlocked_at: u?.unlocked_at || null };
  });
}

module.exports = { ACHIEVEMENTS, checkAndAward, getUserAchievements };

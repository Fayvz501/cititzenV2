// Built-in keyword moderation + optional AI moderation
const BAD_WORDS = [
  'спам', 'реклама', 'продам', 'купи', 'скидк', 'промокод',
  'казино', 'ставки', 'выигрыш', 'бесплатно', 'заработок',
  'тест123', 'asdfjkl', 'qwerty'
];

const SUS_PATTERNS = [
  /(.)\1{5,}/i,            // repeated chars: aaaaaa
  /https?:\/\//i,          // links
  /t\.me\//i,              // telegram links
  /\b\d{10,}\b/,           // long numbers (phone)
  /[A-Z]{10,}/,            // ALL CAPS strings
];

function moderateText(text) {
  const lower = text.toLowerCase();
  let score = 0;
  let flags = [];

  // Keyword check
  for (const word of BAD_WORDS) {
    if (lower.includes(word)) {
      score += 0.3;
      flags.push(`keyword:${word}`);
    }
  }

  // Pattern check
  for (const pattern of SUS_PATTERNS) {
    if (pattern.test(text)) {
      score += 0.2;
      flags.push(`pattern:${pattern.source.substring(0, 20)}`);
    }
  }

  // Too short
  if (text.length < 5) { score += 0.3; flags.push('too_short'); }

  // Too many caps
  const capsRatio = (text.match(/[A-ZА-Я]/g) || []).length / Math.max(text.length, 1);
  if (capsRatio > 0.7 && text.length > 10) { score += 0.2; flags.push('excessive_caps'); }

  return {
    score: Math.min(score, 1.0),
    flags,
    passed: score < 0.5,
    warning: score >= 0.3 && score < 0.5 ? 'Сообщение помечено для проверки' : null
  };
}

// Optional AI moderation via external API
async function aiModerate(text) {
  const url = process.env.AI_MODERATION_URL;
  const key = process.env.AI_MODERATION_KEY;
  if (!url || !key) return null;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{
          role: 'system',
          content: 'You are a content moderator. Analyze the following incident report text. Reply ONLY with JSON: {"safe":true/false,"reason":"...","score":0.0-1.0}. Score 0=safe, 1=harmful.'
        }, {
          role: 'user',
          content: text
        }],
        max_tokens: 100
      })
    });
    const data = await res.json();
    const content = data.choices?.[0]?.message?.content || '';
    return JSON.parse(content);
  } catch (e) {
    console.error('AI moderation error:', e.message);
    return null;
  }
}

async function fullModeration(text) {
  const basic = moderateText(text);
  const ai = await aiModerate(text);

  if (ai) {
    const combined = (basic.score + ai.score) / 2;
    return { ...basic, score: combined, ai_result: ai, passed: combined < 0.5 };
  }

  return basic;
}

module.exports = { moderateText, aiModerate, fullModeration };

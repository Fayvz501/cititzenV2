const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');
const DB_PATH = path.join(__dirname, '..', 'db', 'citizen.db');

let db = null;

// ── Wrapper to match better-sqlite3 API ──
class Statement {
  constructor(database, sql) { this.database = database; this.sql = sql; }

  run(...params) {
    const p = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
    this.database.run(this.sql, p);
    const r = this.database.exec("SELECT last_insert_rowid() as id");
    return { changes: this.database.getRowsModified(), lastInsertRowid: r.length && r[0].values.length ? r[0].values[0][0] : 0 };
  }

  get(...params) {
    const p = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
    try {
      const s = this.database.prepare(this.sql);
      if (p.length) s.bind(p);
      if (s.step()) { const cols = s.getColumnNames(), vals = s.get(); s.free(); const row = {}; cols.forEach((c, i) => row[c] = vals[i]); return row; }
      s.free(); return undefined;
    } catch { return undefined; }
  }

  all(...params) {
    const p = params.length === 1 && Array.isArray(params[0]) ? params[0] : params;
    try {
      const results = [], s = this.database.prepare(this.sql);
      if (p.length) s.bind(p);
      while (s.step()) { const cols = s.getColumnNames(), vals = s.get(), row = {}; cols.forEach((c, i) => row[c] = vals[i]); results.push(row); }
      s.free(); return results;
    } catch { return []; }
  }
}

class DbWrapper {
  constructor(database) { this.database = database; }
  prepare(sql) { return new Statement(this.database, sql); }
  exec(sql) { this.database.run(sql); }
  pragma(str) { try { this.database.run(`PRAGMA ${str}`); } catch {} }
  save() { try { const d = this.database.export(); fs.mkdirSync(path.dirname(DB_PATH), { recursive: true }); fs.writeFileSync(DB_PATH, Buffer.from(d)); } catch (e) { console.error('[DB] Save:', e.message); } }
  close() { this.save(); this.database.close(); }
}

async function initDb() {
  if (db) return db;
  const SQL = await initSqlJs();
  let database;
  if (fs.existsSync(DB_PATH)) { database = new SQL.Database(fs.readFileSync(DB_PATH)); }
  else { fs.mkdirSync(path.dirname(DB_PATH), { recursive: true }); database = new SQL.Database(); }

  db = new DbWrapper(database);
  db.pragma('foreign_keys = ON');
  initSchema();
  setInterval(() => { if (db) db.save(); }, 30000);
  process.on('SIGINT', () => { if (db) db.close(); process.exit(); });
  process.on('SIGTERM', () => { if (db) db.close(); process.exit(); });
  return db;
}

function getDb() {
  if (!db) throw new Error('DB not ready — call initDb() first');
  return db;
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, avatar_color TEXT DEFAULT '#ff3b3b', reputation INTEGER DEFAULT 0, is_streamer INTEGER DEFAULT 0, trust_level TEXT DEFAULT 'newcomer', is_patrolling INTEGER DEFAULT 0, patrol_lat REAL, patrol_lng REAL, lang TEXT DEFAULT 'ru', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, last_active DATETIME DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS incidents (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, type TEXT NOT NULL, description TEXT NOT NULL, address TEXT, lat REAL NOT NULL, lng REAL NOT NULL, severity INTEGER DEFAULT 1, status TEXT DEFAULT 'active', is_emergency INTEGER DEFAULT 0, moderation_score REAL DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, resolved_at DATETIME, FOREIGN KEY (user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS incident_media (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER NOT NULL, filename TEXT NOT NULL, original_name TEXT, mime_type TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS votes (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER NOT NULL, vote_type TEXT NOT NULL, weight REAL DEFAULT 1.0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id), UNIQUE(incident_id, user_id));
    CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER NOT NULL, text TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER NOT NULL, text TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS streamer_claims (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER NOT NULL, status TEXT DEFAULT 'en_route', claimed_at DATETIME DEFAULT CURRENT_TIMESTAMP, arrived_at DATETIME, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id), UNIQUE(incident_id, user_id));
    CREATE TABLE IF NOT EXISTS incident_timeline (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER NOT NULL, user_id INTEGER, event_type TEXT NOT NULL, description TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, incident_id INTEGER, type TEXT NOT NULL, message TEXT NOT NULL, message_en TEXT, is_read INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id), FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS user_zones (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, label TEXT DEFAULT 'Мой район', lat REAL NOT NULL, lng REAL NOT NULL, radius_km REAL DEFAULT 2.0, FOREIGN KEY (user_id) REFERENCES users(id), UNIQUE(user_id, label));
    CREATE TABLE IF NOT EXISTS push_subscriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, endpoint TEXT NOT NULL, keys_p256dh TEXT NOT NULL, keys_auth TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id), UNIQUE(endpoint));
    CREATE TABLE IF NOT EXISTS achievements (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, achievement_key TEXT NOT NULL, unlocked_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id), UNIQUE(user_id, achievement_key));
    CREATE TABLE IF NOT EXISTS emergency_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL, radius_km REAL DEFAULT 5.0, active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, expires_at DATETIME, FOREIGN KEY (user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS area_safety (id INTEGER PRIMARY KEY AUTOINCREMENT, area_lat REAL NOT NULL, area_lng REAL NOT NULL, period TEXT NOT NULL, total_incidents INTEGER DEFAULT 0, fire_count INTEGER DEFAULT 0, crime_count INTEGER DEFAULT 0, accident_count INTEGER DEFAULT 0, medical_count INTEGER DEFAULT 0, safety_score REAL DEFAULT 100, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(area_lat, area_lng, period));
  `);
  const idxs = [
    'CREATE INDEX IF NOT EXISTS idx_inc_st ON incidents(status)',
    'CREATE INDEX IF NOT EXISTS idx_inc_cr ON incidents(created_at)',
    'CREATE INDEX IF NOT EXISTS idx_inc_co ON incidents(lat,lng)',
    'CREATE INDEX IF NOT EXISTS idx_inc_ty ON incidents(type)',
    'CREATE INDEX IF NOT EXISTS idx_com_in ON comments(incident_id)',
    'CREATE INDEX IF NOT EXISTS idx_vot_in ON votes(incident_id)',
    'CREATE INDEX IF NOT EXISTS idx_not_us ON notifications(user_id,is_read)',
    'CREATE INDEX IF NOT EXISTS idx_cha_in ON chat_messages(incident_id)',
    'CREATE INDEX IF NOT EXISTS idx_tl_in ON incident_timeline(incident_id)',
    'CREATE INDEX IF NOT EXISTS idx_ach_us ON achievements(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_med_in ON incident_media(incident_id)',
    'CREATE INDEX IF NOT EXISTS idx_psh_us ON push_subscriptions(user_id)',
  ];
  for (const i of idxs) { try { db.exec(i); } catch {} }
  db.save();
}

module.exports = { initDb, getDb };
